Własny projekt do wspomagania zarządzania posiadanymi autami.

Funkcjonalności:
-Tworzenie pojazdow ze względu na ich typ, dodawanie zdjęcia
-Tworzenie ubezpieczeń OC i przyporządkowywanie ich samochodom, przypomnienie o końcu OC
-Tworzenie przeglądów technicznych i j/w
-Dodawanie tankowań (zrobione), przyporządkowywanie ich samochodom oraz tworzenie statystyk zużycia paliwa (TBD)
-Dodawanie napraw, statystyki napraw (TBD)
-Kalendarz napraw, przeglądów, końców ubezpieczeń (TBD)
-Kalkulator kosztów wynajęcia pojazdu, generowanie PDFa z umową najmu (TBD)